#include <stdio.h> 

void printDateToday(); 
void printHiNameAge(char* name, int age); 

/*Hiba Sabbagh is working with Delina Sium on lab01*/
#include <stdio.h>
int main (){
	printf("Hello, World! \n"); 
	return 0; 
}

#include <stdio.h>
#include "lab1-04-mylib.h" 


int main(){
	printDateToday(); 
	printHiNameAge("Hiba", 25);

	return 0;
}

